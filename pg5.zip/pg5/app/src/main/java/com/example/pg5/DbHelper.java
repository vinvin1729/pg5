package com.example.pg5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper
{
    public DbHelper(Context context)
    {
        super(context,"userdb.db",null,1);
    }
    public void onCreate(SQLiteDatabase sqLiteDatabase){
        sqLiteDatabase.execSQL("create table userdb(email Text,password Text)");

    }
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int i,int i1){
        sqLiteDatabase.execSQL("drop table if exists userdb");
    }
    public boolean insertdatab(String email,String password){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("email",email);
        cv.put("password",password);
        int res=(int) db.insert("userdb",null,cv);
        if(res==-1){
            return false;
        }
        return true;
    }
    public boolean checkmail(String email,String password){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("select * from userdb where email=? and password=?",new String[]{email,password});
        if(c.getCount()>0){
            return true;
        }
        return false;
    }
}
